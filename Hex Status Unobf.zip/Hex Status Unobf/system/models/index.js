const Service = require('./Service');
const Admin = require('./Admin');
const StatusMessage = require('./StatusMessage');

module.exports = {
    Service,
    Admin,
    StatusMessage
};
